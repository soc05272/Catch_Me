// 미션 : 랜덤으로 뜨는거 과거내역은 안 뜨고 그냥 하나만 뜨게 만들기 -> 과제로 해오삼 + 클릭 시 점수가 올라가고 진행시간을 타이머로 하기

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
//import javax.swing.Timer;

class RandomThread extends Thread
{
	Container c;
	JLabel imgLa;
	public RandomThread(Container c, JLabel imgLa) {
		this.c = c;
		this.imgLa = imgLa;
	}
	@Override
	public void run() {
		while(true)
		{
			int x = (int)(Math.random() * c.getWidth());
			int y = (int)(Math.random() * c.getHeight());
			imgLa.setLocation(x, y);
			
			try {
				sleep(500);
			}catch(InterruptedException e) {return;}
		}
	}
}

public class CatchMe extends JFrame implements ActionListener, Runnable{

	JButton start = new JButton("Start"); // 시작버틑
	JButton set[] = new JButton[12]; // 너구리 나타나게 하는 버튼
	
	ImageIcon icon = new ImageIcon("너구리.jpg");
	ImageIcon icon2 = new ImageIcon("Square.png");
	
	JLabel score = new JLabel("Score : 0");
	JLabel time = new JLabel("Time 0 : 30");
	
	Container c = getContentPane();
	
	JPanel PanelD = new JPanel(); //가운데에 set[] 버튼 놓을 패널
	JPanel PanelSc = new JPanel(); //밑부분 왼쪽 점수레이블 넣을 패널
	JPanel PanelSt = new JPanel(); //밑부분 오른쪽에 시작버튼 넣을 패널
	int ran1 = 0;
	int ran2 = 0;
	int cnt = -1;
	int n = 30;
	
	CatchMe(){
		setTitle("catch");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		
		//JPanel PanelD = new JPanel();
		
		c.setLayout(new FlowLayout());
		c.setLayout(new BorderLayout(10,10));
		
		time.setFont(new Font("Arial",Font.BOLD,20));
		score.setFont(new Font("Arial",Font.BOLD,20));
		
		c.add(time,BorderLayout.NORTH);
		
		c.add(PanelD,BorderLayout.CENTER);
		PanelD.setLayout(new GridLayout(3,4));
		for(int i=0;i<set.length; i++) {
			set[i] = new JButton();
			PanelD.add(set[i],BorderLayout.CENTER);
			set[i].setIcon(icon2);
			set[i].setBorderPainted(false);
			set[i].setFocusPainted(false);
			set[i].setBackground(Color.DARK_GRAY);
		}
		
		c.add(PanelSc,BorderLayout.SOUTH);
		PanelSc.setLayout(new GridLayout(1,2));
		PanelSc.add(score);
		
		PanelSc.add(PanelSt);
		PanelSt.setLayout(new FlowLayout(FlowLayout.RIGHT));
		PanelSt.add(start);
		
		PanelD.setBackground(Color.DARK_GRAY);
		PanelSt.setBackground(Color.LIGHT_GRAY);
		PanelSc.setBackground(Color.LIGHT_GRAY);
		c.setBackground(Color.LIGHT_GRAY);
		
		//ImageIcon icon = new ImageIcon("너구리.jpg");
		/*JLabel imgLa = new JLabel(icon);
		imgLa.setLocation(100,100);
		imgLa.setSize(10,10);
		c.add(imgLa);
		
		RandomThread th = new RandomThread(c,imgLa);
		th.start();*/
		Start();
		
		setSize(500,500);
		setVisible(true);
	}
	
	public void Start() {
		on();
		start.addActionListener(this);
		for(int i=0; i<set.length; i++)
			set[i].addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == start) {
			Thread th = new Thread(this);
			th.start();
			random(0);
		}
		for(int i=0; i<set.length; i++) {
			if(e.getSource() == set[i])
				random(i);
		}		
	}
	
	private void random(int i) {
		if (i != ran1 && i != ran2) return; 
		cnt ++;


		Timer tm = new Timer();
		TimerTask m_task = new TimerTask() {

			@Override
			public void run() {
				set[ran1].setIcon(icon2); //null
				ran1 = (int)(Math.random() * set.length);
				set[ran1].setIcon(icon);
			}
			
		};
		tm.schedule(m_task, 1500);
		
		set[ran2].setIcon(icon2); //null
		ran2 = (int)(Math.random() * set.length);
		set[ran2].setIcon(icon);
		
		score.setText("Score : "+cnt*10);
	}
	
	@Override
	public void run() { // 타이머
		n = 30;
		while(true) {
			try{
				Thread.sleep(1000);
			}catch(InterruptedException e) {};
			n--;
			if(n == 0) { 
				set[ran1].setIcon(icon2);	//null
				set[ran2].setIcon(icon2);	//null
				time.setText("Game Over !!");
				off();
				break;
			}
			time.setText("Time 0:"+n);
		}
		
	}
	
	public void off() {
		for(int i=0; i<set.length; i++)
			set[i].setEnabled(false);
	}
	public void on() {
		for(int i=0; i<set.length; i++)
			set[i].setEnabled(true);
	}

	public static void main(String[] args) {
		new CatchMe();
	}	
}